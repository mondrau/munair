import { Header } from "@/components/header"
import { Hero } from "@/components/hero"
import { Projects } from "@/components/projects"
import { Clients } from "@/components/clients"
import { Features } from "@/components/features"
import { Services } from "@/components/services"
import { Marquee } from "@/components/marquee"
import { Benefits } from "@/components/benefits"
import { CTA } from "@/components/cta"
import { Footer } from "@/components/footer"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Header />
      <Hero />
      <Projects />
      <Clients />
      <Features />
      <Services />
      <Marquee />
      <Benefits />
      <CTA />
      <Footer />
    </main>
  )
}
