import Link from "next/link"
import { Twitter, Linkedin, Dribbble, Instagram } from "lucide-react"

const footerLinks = {
  Letter: ["School Principal", "Secretary General", "Director General"],
  Committees: ["EASA", "IATA", "SPECPOL", "H-ICAO", "OECD", "H-AIA", "JCC"],
  Contact: ["pr@munair.org", "+90 (549) 719 84 65", "Ulus, Çanakkale Asfaltı Cd. Üzeri No.131, 35672 Menemen/İzmir"]
}

export function Footer() {
  return (
    <footer className="border-t border-border py-16 md:py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-12">
          <div className="lg:col-span-2">
            <Link href="/" className="flex items-center gap-2 mb-6">
              
              <span className="font-bold text-xl">MUNAIR'26</span>
            </Link>
            <p className="text-muted-foreground max-w-sm mb-6 leading-relaxed">
              The most prestigious and academic Model United Nations conferance, in Izmir.
            </p>
            <div className="flex gap-4">
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="Twitter">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="LinkedIn">
                <Linkedin className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="Dribbble">
                <Dribbble className="w-5 h-5" />
              </a>
              <a href="#" className="text-muted-foreground hover:text-foreground transition-colors" aria-label="Instagram">
                <Instagram className="w-5 h-5" />
              </a>
            </div>
          </div>

          {Object.entries(footerLinks).map(([title, links]) => (
            <div key={title}>
              <h4 className="font-semibold mb-4">{title}</h4>
              <ul className="space-y-3">
                {links.map((link) => (
                  <li key={link}>
                    <a
                      href="#"
                      className="text-muted-foreground hover:text-foreground transition-colors"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-border mt-16 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-muted-foreground text-sm">
            © 2026 mondr.au
          </p>
          <div className="flex gap-6 text-sm">
            <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
              Privacy Policy
            </a>
            <a href="#" className="text-muted-foreground hover:text-foreground transition-colors">
              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>
  )
}
