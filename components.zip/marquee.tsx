const problems = [
  { text: "Fulfilling", highlight: "academic experience" },
  { text: "Experienced", highlight: "teams" },
  { text: "", highlight: "Prestigious", suffix: "awards" },
  { text: "Signature", highlight: "workshops" },
  { text: "Transportation", highlight: "opportunities" },
  { text: "Unique", highlight: "committees" },
  { text: "Prevailing", highlight: "certificate" },
  { text: "Systems", highlight: "shuffling the deck" },
  { text: "Expertise", highlight: "consultants" },
  { text: "", highlight: "Always-on-guard", suffix: "PR members" }
]

export function Marquee() {
  return (
    <section className="py-20 md:py-32 bg-foreground text-background overflow-hidden">
      <div className="max-w-7xl mx-auto px-6 mb-12">
        <h2 className="text-4xl md:text-5xl font-bold">We undertake you</h2>
      </div>

      <div className="relative">
        <div className="flex animate-marquee">
          {[...problems, ...problems].map((problem, index) => (
            <div
              key={`${problem.highlight}-${index}`}
              className="flex-shrink-0 px-6 py-4 mx-2 border border-background/20 rounded-full whitespace-nowrap"
            >
              {problem.text && <span className="opacity-60">{problem.text} </span>}
              <span className="font-semibold">{problem.highlight}</span>
              {problem.suffix && <span className="opacity-60"> {problem.suffix}</span>}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
