"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu, X } from "lucide-react"
import { Button } from "@/components/ui/button"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
        <Link href="/" className="flex items-center gap-2">
          
          <span className="font-bold text-xl hidden sm:block">MUNAIR'26</span>
        </Link>

        <nav className="hidden md:flex items-center gap-8">
          <Link href="#work" className="text-muted-foreground hover:text-foreground transition-colors">
            Apply
          </Link>
          <Link href="#services" className="text-muted-foreground hover:text-foreground transition-colors">
            Committees
          </Link>
          <Link href="#about" className="text-muted-foreground hover:text-foreground transition-colors">
            Letter
          </Link>
          <Link href="#blog" className="text-muted-foreground hover:text-foreground transition-colors">
            Home
          </Link>
        </nav>

        <div className="flex items-center gap-4">
          <Button className="hidden md:flex rounded-full px-6">
            Inquiries
          </Button>
          <button
            type="button"
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden bg-background border-t border-border">
          <nav className="flex flex-col p-6 gap-4">
            <Link href="#work" className="text-lg hover:text-muted-foreground transition-colors">
              Work
            </Link>
            <Link href="#services" className="text-lg hover:text-muted-foreground transition-colors">
              Services
            </Link>
            <Link href="#about" className="text-lg hover:text-muted-foreground transition-colors">
              About
            </Link>
            <Link href="#blog" className="text-lg hover:text-muted-foreground transition-colors">
              Blog
            </Link>
            <Button className="rounded-full mt-4">Let's talk</Button>
          </nav>
        </div>
      )}
    </header>
  )
}
