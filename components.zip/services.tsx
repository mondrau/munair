"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

const services = [
  {
    id: "strategy",
    title: "School Principal",
    description: "Suat Yılmazok - Principal of Havajet Aviation High School",
    bgColor: "bg-lavender",
    categories: [
      {
        name: "Growth",
        items: ["UX/UI Audits", "Accessibility Audits", "Conversion Optimization"]
      },
      {
        name: "Creative",
        items: ["Brand Strategy", "Creative Direction", "Consulting", "Knowledge Sharing"]
      },
      {
        name: "Technical",
        items: ["Technical Strategy", "Consulting", "Technical Audits"]
      },
      {
        name: "Enablement",
        items: ["Operational advisory", "Courses & Workshops", "Knowledge sharing"]
      }
    ]
  },
  {
    id: "design",
    title: "Secretar General",
    description: "Rüzgar Efe Taşın - Secretary General of MUNAIR'26",
    bgColor: "bg-mint",
    categories: [
      {
        name: "Esteemed Participants,",
        items: ["My name is Rüzgar and I am a junior student at Havajet Aviation High School, where MUNAIR’26 will take place. It is both an honor and a great excitement for me to organize the second official session of Air Model United Nations as the Secretary-General. Since our first conference last year, we have grown in every sense. Our experience has deepened, our network has expanded, and our team has become stronger and more united. What once seemed like a bold dream has now transformed into a tradition we are proud to continue. I strongly believe that work done with sincerity and honesty gains true meaning and leaves a lasting impact. This belief guides not only how we organize this conference, but also how we approach life itself. With passion and dedication, we have worked tirelessly to offer you an unforgettable MUN experience. Our aim has always been to raise the bar—and we are ready to do so once again. We are confident, because we are aware of both our responsibilities and our capabilities. In return, we eagerly await your enthusiasm and commitment. I am confident that throughout the conference, we will uphold mutual respect, engage in meaningful debate, and give our very best without hesitation. If you have any questions or concerns, please feel free to reach out to me or any member of our team. I look forward to meeting you on February 27. "]
      },
    ]
  },
  {
    id: "development",
    title: "Director General",
    description: "Yalın Deniz Arı - Director General of MUNAIR'26",
    bgColor: "bg-peach",
    categories: [
      {
        name: "Build",
        items: ["Front-end Development", "Back-end Development", "Website Development", "No-code Development", "Product Development", "Native Apps"]
      },
      {
        name: "Integration",
        items: ["API Integrations", "Headless Integrations", "Plug-ins & Add-ons", "Design Systems", "AI"]
      },
      {
        name: "Optimize",
        items: ["Accessibility (WCAG) 2.1", "Technical Research", "Animations & Interactions", "Performance Optimization", "Monitoring", "Maintenance"]
      }
    ]
  }
]

export function Services() {
  const [openService, setOpenService] = useState<string | null>("strategy")

  return (
    <section id="services" className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-bold mb-6">Letters</h2>
        <p className="text-lg md:text-xl text-muted-foreground mb-12 max-w-2xl">
          Read the letters which are written by our executive.
        </p>

        <div className="space-y-4">
          {services.map((service) => (
            <div
              key={service.id}
              className={`rounded-3xl overflow-hidden transition-all ${service.bgColor}`}
            >
              <button
                type="button"
                onClick={() => setOpenService(openService === service.id ? null : service.id)}
                className="w-full p-6 md:p-8 flex items-center justify-between text-left"
              >
                <div>
                  <h3 className="text-2xl md:text-3xl font-bold mb-2">
                    {service.title}
                  </h3>
                  <p className="text-muted-foreground">{service.description}</p>
                </div>
                <ChevronDown
                  className={`w-6 h-6 transition-transform flex-shrink-0 ml-4 ${
                    openService === service.id ? "rotate-180" : ""
                  }`}
                />
              </button>

              {openService === service.id && (
                <div className="px-6 md:px-8 pb-8">
                  <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 pt-4 border-t border-foreground/10">
                    {service.categories.map((category) => (
                      <div key={category.name}>
                        <h4 className="font-semibold mb-3 text-sm uppercase tracking-wide">
                          {category.name}
                        </h4>
                        <ul className="space-y-2">
                          {category.items.map((item) => (
                            <li
                              key={item}
                              className="text-sm text-foreground/80 hover:text-foreground cursor-pointer transition-colors"
                            >
                              {item}
                            </li>
                          ))}
                        </ul>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
