import { ArrowRight } from "lucide-react"

export function Hero() {
  return (
    <section className="relative min-h-screen flex items-center pt-20 overflow-hidden">
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute top-20 right-0 w-96 h-96 bg-mint/30 rounded-full blur-3xl" />
        <div className="absolute bottom-20 left-0 w-80 h-80 bg-peach/30 rounded-full blur-3xl" />
        <div className="absolute top-1/2 left-1/2 w-64 h-64 bg-lavender/20 rounded-full blur-3xl" />
      </div>

      <div className="max-w-7xl mx-auto px-6 py-20 relative z-10">
        <div className="max-w-4xl">
          <p className="text-muted-foreground mb-4 text-lg">
            Digital product agency for tech scale-ups — Yummygum
          </p>
          <h1 className="text-5xl md:text-7xl lg:text-8xl font-bold leading-tight mb-8 text-balance">
            Unwrap your
            <br />
            <span className="text-muted-foreground">tiny landing page.</span>
          </h1>
          <p className="text-xl md:text-2xl text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            Yummygum is a digital product agency.
            <br />
            We help scaling tech companies take their platform from good to{" "}
            <span className="text-foreground font-medium">'wow'</span>.
          </p>
          <button
            type="button"
            className="group inline-flex items-center gap-2 text-lg font-medium hover:gap-4 transition-all"
          >
            Learn more
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>
    </section>
  )
}
