import { Users, Zap, MessageSquare, BookOpen } from "lucide-react"

const benefits = [
  {
    icon: Users,
    title: "Top-tier team of experts",
    description:
      "Even the best teams need help. Following industry standards and beyond, our team of experts knows exactly what tools, methods and stack works best in your situation."
  },
  {
    icon: Zap,
    title: "Proven powerful process",
    description:
      "Stop hitting snooze on updating your product's look and feel, launching that gold-nugget feature, or shaking off technical debt. Our trusty process is set up to make power moves."
  },
  {
    icon: MessageSquare,
    title: "Clear-cut comms",
    description:
      "Slow and foggy communication weighs down on your ability to scale efficiently. Whether it's a Slack message, a video call, or an on-site session, we value clarity."
  },
  {
    icon: BookOpen,
    title: "Sharing knowledge",
    description:
      "Building a high quality and scalable product takes ongoing effort. After helping you level up we enable your in-house teams to keep up the pace. We hand-off our work *and* expertise."
  }
]

export function Benefits() {
  return (
    <section className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-bold mb-16">Placeholdertext</h2>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {benefits.map((benefit) => (
            <div
              key={benefit.title}
              className="flex gap-6 p-6 rounded-2xl hover:bg-secondary/50 transition-colors"
            >
              <div className="flex-shrink-0">
                <div className="w-12 h-12 rounded-xl bg-mint flex items-center justify-center">
                  <benefit.icon className="w-6 h-6" />
                </div>
              </div>
              <div>
                <h3 className="text-xl md:text-2xl font-bold mb-3">
                  {benefit.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
