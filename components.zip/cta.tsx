import { ArrowRight } from "lucide-react"
import { Button } from "@/components/ui/button"

export function CTA() {
  return (
    <section className="py-20 md:py-32 relative overflow-hidden">
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-mint/20 rounded-full blur-3xl" />
        
      </div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="text-background rounded-3xl p-12 md:p-20 text-center bg-card-foreground">
          <h2 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-8">
            Any inquiries?
          </h2>
          <p className="text-xl md:text-2xl opacity-80 mb-10 max-w-2xl mx-auto">
            You can reach out our Public Relations Team for any of your questions and requests, anytime.
          </p>
          <Button
            size="lg"
            variant="secondary"
            className="rounded-full px-8 py-6 text-lg group"
          >
            Get in touch
            <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </Button>
        </div>
      </div>
    </section>
  )
}
