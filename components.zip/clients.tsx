const clients = [
  "Figma",
  "Notion",
  "Linear",
  "Stripe",
  "Vercel",
  "Spotify",
  "Slack",
  "Discord",
  "Dropbox",
  "Shopify"
]

export function Clients() {
  return (
    <section className="py-20 md:py-32 border-t border-border">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
          Collaborators
        </h2>
        <p className="text-muted-foreground text-center mb-16 text-lg">
          Who supports our conferance.
        </p>

        <div className="flex flex-wrap justify-center gap-8 md:gap-12 opacity-60">
          {clients.map((client) => (
            <div
              key={client}
              className="text-xl md:text-2xl font-semibold text-muted-foreground hover:text-foreground transition-colors cursor-pointer"
            >
              {client}
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
