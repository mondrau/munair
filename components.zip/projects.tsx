import { ProjectCard } from "./project-card"

const projects = [
  {
    title: "Delegate",
    description:
      "To uphold policies of governances in assemblies.",
    tags: ["Brand Strategy", "Technical Strategy", "Creative Direction"],
    moreCount: 7,
    bgColor: "bg-foreground",
    textColor: "text-background"
  },
  {
    title: "Chairboard",
    description:
      "To get delegates stay abreast of the main agenda of committee.",
    tags: ["Conversion optimization", "Website Design", "Website Development"],
    moreCount: 1,
    bgColor: "bg-mint",
    textColor: "text-foreground"
  },
  {
    title: "Organization Team Member",
    description:
      "To assume photographical or processal works of the conferance.",
    tags: ["Brand Strategy", "Knowledge Sharing", "User Research"],
    moreCount: 9,
    bgColor: "bg-peach",
    textColor: "text-foreground"
  }
]

export function Projects() {
  return (
    <section id="work" className="py-20 md:py-32">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((project) => (
            <ProjectCard key={project.title} {...project} />
          ))}
        </div>
      </div>
    </section>
  )
}
