import { Layers, Palette, Globe } from "lucide-react"

const features = [
  {
    icon: Layers,
    title: "data1",
    description:
      "data1 description"
  },
  {
    icon: Palette,
    title: "data2",
    description:
      "data2 description"
  },
  {
    icon: Globe,
    title: "data3",
    description:
      "data3 description"
  }
]

export function Features() {
  return (
    <section className="py-20 md:py-32 bg-secondary/50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="max-w-3xl mb-16">
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight leading-3">
            Stirring
            <br />
            <span className="text-muted-foreground">committees.</span>
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
            Lorem ipsum dolor sit amet.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="bg-card rounded-2xl p-8 border border-border hover:shadow-lg transition-shadow"
            >
              <feature.icon className="w-10 h-10 mb-6 text-foreground" />
              <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
