import { ArrowUpRight } from "lucide-react"

interface ProjectCardProps {
  title: string
  description: string
  tags: string[]
  moreCount?: number
  bgColor: string
  textColor?: string
}

export function ProjectCard({
  title,
  description,
  tags,
  moreCount,
  bgColor,
  textColor = "text-foreground"
}: ProjectCardProps) {
  return (
    <div
      className={`group relative rounded-3xl p-8 md:p-10 ${bgColor} min-h-[400px] flex flex-col justify-between cursor-pointer transition-transform hover:scale-[1.02]`}
    >
      <div className="absolute top-6 right-6 opacity-0 group-hover:opacity-100 transition-opacity">
        <ArrowUpRight className={`w-6 h-6 ${textColor}`} />
      </div>

      <div className="flex-1" />

      <div>
        <h3 className={`text-3xl md:text-4xl font-bold mb-4 ${textColor}`}>{title}</h3>
        <p className={`text-base md:text-lg mb-6 ${textColor} opacity-80 leading-relaxed`}>
          {description}
        </p>
        <div className="flex flex-wrap gap-2">
          {tags.map((tag) => (
            <span
              key={tag}
              className={`px-3 py-1 rounded-full text-sm ${textColor} bg-foreground/10`}
            >
              {tag}
            </span>
          ))}
          {moreCount && moreCount > 0 && (
            <span className={`px-3 py-1 rounded-full text-sm ${textColor} bg-foreground/10`}>
              + {moreCount}
            </span>
          )}
        </div>
      </div>
    </div>
  )
}
